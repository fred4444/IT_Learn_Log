..  _cli:

.. index::
   single: Command Line Interface (CLI)

Command Line Interface (CLI)
============================

This section is about the commandline interface of docxtemplater.

To install the cli, please use this command :

npm install -g docxtemplater-cli

https://github.com/open-xml-templating/docxtemplater-cli

The syntax is the following:

    docxtemplater input.docx data.json output.docx
