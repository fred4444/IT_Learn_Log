module.exports = {
	XMLSerializer: window.XMLSerializer,
	DOMParser: window.DOMParser,
	XMLDocument: window.XMLDocument,
};
