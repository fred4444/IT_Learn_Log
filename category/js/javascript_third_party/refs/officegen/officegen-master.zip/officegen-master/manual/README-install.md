# Installation: #

via [**yarn**](https://yarnpkg.com/):

```bash
$ yarn add officegen
```

via **npm**:

```bash
$ npm install officegen
```

or if you are enthusiastic about using the latest that officegen has to offer (beware - may be unstable), you can install directly from the officegen repository using:

```bash
$ npm install Ziv-Barber/officegen#master
```

Now that you added officegen to your project, let's [use it](README-basic.md)!
