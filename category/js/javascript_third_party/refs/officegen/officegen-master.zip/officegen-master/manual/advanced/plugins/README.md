# Plugins:

List of plugins types:

- [New document type](new/README.md)
	- [New Microsoft Office based document type](msdoc/README.md)
	- [New OpenOffice based document type](oodoc/README.md)
- Extenting existing document types with new features:
	- [docplug](docplug/README.md)
	- [Extending the Microsoft PowerPoint document type](pptx/README.md)
	- [Extending the Microsoft Word document type](docx/README.md)
	- [Extending the Microsoft Excel document type](xlsx/README.md)
- [Go back to the advanced topics documentation](../README.md)
- [Go back to the main documentation](../../README.md)
