# Advanced topics:

- [Plugins](plugins/README.md)
- [Go back to the main documentation](../README.md)
