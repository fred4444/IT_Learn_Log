# Writing a Microsoft Word document type plugin:

TBD

- [Go back to the plugins documentation](../README.md)
- [Go back to the advanced topics documentation](../../README.md)
- [Go back to the main documentation](../../../README.md)
