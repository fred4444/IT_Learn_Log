### Environment

1. `node -v`: [fill]
1. `npm -v`: [fill]
1. `npm ls officegen`: [fill]
1. Operating system: [fill]
1. Microsoft Office version: [fill]
1. Problem with Powerpoint, Excel or Word document: [fill]

### Steps to Reproduce

<!-- Please create a repository that reproduces the issue with the minimal amount of code possible. -->

[fill]

### Expected Behavior

[fill]

### Actual Behavior

[fill]

--- 

An example code will be the best.
The fastest (and the most fun) way to resolve the issue is to submit a pull-request yourself.
